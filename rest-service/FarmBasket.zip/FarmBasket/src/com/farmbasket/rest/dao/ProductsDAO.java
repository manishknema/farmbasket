package com.farmbasket.rest.dao;

import javax.ws.rs.core.Response;

public interface ProductsDAO {

	public Response getAllProducts();
	
}
